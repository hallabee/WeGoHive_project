package com.dev.restLms.ModifyCourse.projection;

public interface ModifyCourseSubjectOwnVideo {
    String getEpisodeId();
    String getSovVideoId();
}
