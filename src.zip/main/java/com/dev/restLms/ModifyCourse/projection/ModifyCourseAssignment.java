package com.dev.restLms.ModifyCourse.projection;

public interface ModifyCourseAssignment {
    String getAssignmentId();
}
