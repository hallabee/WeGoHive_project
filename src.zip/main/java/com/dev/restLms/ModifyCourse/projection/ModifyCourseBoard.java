package com.dev.restLms.ModifyCourse.projection;

public interface ModifyCourseBoard {
    String getBoardId();
}
