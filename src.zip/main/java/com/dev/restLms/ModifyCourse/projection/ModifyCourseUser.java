package com.dev.restLms.ModifyCourse.projection;

public interface ModifyCourseUser {
    String getUserName();
}
