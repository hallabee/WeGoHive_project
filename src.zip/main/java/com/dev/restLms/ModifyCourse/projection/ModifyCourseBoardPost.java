package com.dev.restLms.ModifyCourse.projection;

public interface ModifyCourseBoardPost {
    String getPostId();
    String getFileNo();
}
