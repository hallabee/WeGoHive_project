package com.dev.restLms.ModifyCourse.projection;

public interface ModifyCourseComment {
    String getCommentId();
}
