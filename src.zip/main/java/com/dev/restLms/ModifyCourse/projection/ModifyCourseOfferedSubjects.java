package com.dev.restLms.ModifyCourse.projection;

public interface ModifyCourseOfferedSubjects {
    String getOfferedSubjectsId();
}
