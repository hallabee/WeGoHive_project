package com.dev.restLms.ModifyCourse.projection;

public interface ModifyCourseOwnSubject {
    String getSubjectId();
    String getIncreaseId();
}
