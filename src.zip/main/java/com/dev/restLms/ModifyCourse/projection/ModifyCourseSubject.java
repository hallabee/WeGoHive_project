package com.dev.restLms.ModifyCourse.projection;

public interface ModifyCourseSubject {
    String getSubjectId();
    String getSubjectName();
    String getSubjectDesc();
    String getSubjectCategory();
    String getTeacherSessionId();
}
