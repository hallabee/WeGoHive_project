package com.dev.restLms.ModifyCourse.dto;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class subjectDto {
    String subjectName;
    String subjectDesc;
    String SubjectCategory;
}
