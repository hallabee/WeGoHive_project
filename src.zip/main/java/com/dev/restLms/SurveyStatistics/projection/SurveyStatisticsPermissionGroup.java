package com.dev.restLms.SurveyStatistics.projection;

public interface SurveyStatisticsPermissionGroup {
    String getPermissionGroupUuid();

    String getPermissionName();
}
