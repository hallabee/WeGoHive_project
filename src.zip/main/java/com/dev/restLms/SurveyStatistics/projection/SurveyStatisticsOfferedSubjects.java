package com.dev.restLms.SurveyStatistics.projection;

public interface SurveyStatisticsOfferedSubjects {
    String getOfferedSubjectsId();

    String getSubjectId();
}
