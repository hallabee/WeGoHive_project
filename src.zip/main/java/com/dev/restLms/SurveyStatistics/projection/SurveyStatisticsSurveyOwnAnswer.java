package com.dev.restLms.SurveyStatistics.projection;

public interface SurveyStatisticsSurveyOwnAnswer {
    String getSurveyAnswerId();

    String getSurveyQuestionId();
    String getAnswerData();
    String getScore();
}
