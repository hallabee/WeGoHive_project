package com.dev.restLms.SurveyStatistics.projection;

public interface SurveyStatisticsSurveyExecution {
    String getSurveyExecutionId();

    String getOfferedSubjectsId();
    String getCourseId();
    String getSessionId();
}
