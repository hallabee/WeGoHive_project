package com.dev.restLms.userSubjects;

public interface userSubjectsUserOwnAssignment {
    String getIncreaseId();
    String getUserSessionId();
    String getOfferedSubjectsId();
    String getSubjectAcceptCategory();
}
