package com.dev.restLms.userSubjects;

public interface userSubjectsOfferedSubjects {
    String getOfferedSubjectsId();
    String getSubjectId();
}
