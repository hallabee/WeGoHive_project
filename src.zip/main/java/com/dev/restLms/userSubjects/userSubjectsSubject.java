package com.dev.restLms.userSubjects;

public interface userSubjectsSubject {
    String getSubjectId();
    String getSubjectName();
    String getSubjectImageLink();
    String getSubjectPromotion();
}
