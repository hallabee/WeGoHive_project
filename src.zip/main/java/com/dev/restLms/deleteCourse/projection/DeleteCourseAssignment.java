package com.dev.restLms.deleteCourse.projection;

public interface DeleteCourseAssignment {
    String getAssignmentId();
}
