package com.dev.restLms.deleteCourse.projection;

public interface DeleteCourseUserOwnAssignmentEvaluation {
    String getSubmissionId();
    String getFileNo();
}
