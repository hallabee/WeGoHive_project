package com.dev.restLms.deleteCourse.projection;

public interface DeleteCourseUserOwnSubjectVideo {
    String getIncreaseId();
}
