package com.dev.restLms.deleteCourse.projection;

public interface DeleteCourseUserOwnAssignment {
    String getIncreaseId();
}
