package com.dev.restLms.deleteCourse.projection;

public interface DeleteCourseBoardPost {
    String getPostId();
    String getFileNo();
}
