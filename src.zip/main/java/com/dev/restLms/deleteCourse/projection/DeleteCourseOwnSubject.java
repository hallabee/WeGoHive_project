package com.dev.restLms.deleteCourse.projection;

public interface DeleteCourseOwnSubject {
    String getIncreaseId();
    String getSubjectId();
}
