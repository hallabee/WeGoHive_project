package com.dev.restLms.deleteCourse.projection;

public interface DeleteCourseUserOwnCourse {
    String getIncreaseId();
}
