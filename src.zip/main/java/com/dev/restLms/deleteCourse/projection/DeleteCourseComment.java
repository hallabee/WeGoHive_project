package com.dev.restLms.deleteCourse.projection;

public interface DeleteCourseComment {
    String getCommentId();
}
