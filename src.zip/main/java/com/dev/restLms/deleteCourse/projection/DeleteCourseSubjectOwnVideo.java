package com.dev.restLms.deleteCourse.projection;

public interface DeleteCourseSubjectOwnVideo {
    String getEpisodeId();
    String getSovVideoId();
}
