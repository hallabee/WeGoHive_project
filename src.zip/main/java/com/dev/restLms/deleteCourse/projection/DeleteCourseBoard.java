package com.dev.restLms.deleteCourse.projection;

public interface DeleteCourseBoard {
    String getBoardId();
}
