package com.dev.restLms.CreateCourse.projection;

public interface CreateCourseOfferedSubjects {
    String getCourseId();
    String getSubjectId();
}
