package com.dev.restLms.CreateCourse.projection;

public interface CreateCourse {
    String getCourseTitle();
}
