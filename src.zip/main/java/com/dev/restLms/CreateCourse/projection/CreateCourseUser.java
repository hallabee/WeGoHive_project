package com.dev.restLms.CreateCourse.projection;

public interface CreateCourseUser {
    String getUserName();
    String getUserBirth();
    String getUserEmail();
    String getPhoneNumber();
    String getFileNo();
}
