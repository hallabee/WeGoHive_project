package com.dev.restLms.CreateCourse.projection;

public interface CreateCourseOwnSubjuct {
    String getSubjectId();
}
