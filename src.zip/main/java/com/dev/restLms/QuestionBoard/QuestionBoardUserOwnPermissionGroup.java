package com.dev.restLms.QuestionBoard;

public interface QuestionBoardUserOwnPermissionGroup {

     String getPermissionGroupUuid2();

     String getSessionId();
    
}
