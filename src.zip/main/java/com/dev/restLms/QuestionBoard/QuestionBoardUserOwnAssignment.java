package com.dev.restLms.QuestionBoard;

public interface QuestionBoardUserOwnAssignment {

     String getIncreaseId();
    
     String getOfferedSubjectsId();

     String getUserSessionId();
    
}
