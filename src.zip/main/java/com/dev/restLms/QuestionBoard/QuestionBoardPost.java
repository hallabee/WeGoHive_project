package com.dev.restLms.QuestionBoard;

public interface QuestionBoardPost {

     String getPostId();

     String getAuthorNickname();

     String getCreatedDate();

     String getTitle();

     String getContent();

     String getBoardId();

     String getSessionId();

     String getIsNotice();
    
}
