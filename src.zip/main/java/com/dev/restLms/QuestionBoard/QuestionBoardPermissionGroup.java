package com.dev.restLms.QuestionBoard;

public interface QuestionBoardPermissionGroup {

     String getPermissionGroupUuid();

     String getPermissionName();
    
}
