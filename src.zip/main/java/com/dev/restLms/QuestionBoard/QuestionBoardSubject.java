package com.dev.restLms.QuestionBoard;

public interface QuestionBoardSubject {

     String getSubjectId();

     String getSubjectName();
    
}
