package com.dev.restLms.QuestionBoard;

public interface QuestionBoardOfferedSubjects {

     String getOfferedSubjectsId();

     String getTeacherSessionId();

     String getSubjectId();

     String getOfficerSessionId();
    
}
