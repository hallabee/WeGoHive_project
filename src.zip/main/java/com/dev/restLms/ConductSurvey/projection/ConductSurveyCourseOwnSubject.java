package com.dev.restLms.ConductSurvey.projection;

public interface ConductSurveyCourseOwnSubject {

    String getIncreaseId();

    String getCourseId();
    String getOfficerSessionId();
    String getSubjectId();
    String getSubjectApproval();
    
}
