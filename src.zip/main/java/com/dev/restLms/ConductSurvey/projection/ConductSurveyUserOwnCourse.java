package com.dev.restLms.ConductSurvey.projection;

public interface ConductSurveyUserOwnCourse {
    
    String getIncreaseId();

    String getSessionId();
    String getCourseId();
    String getOfficerSessionId();
    
}
