package com.dev.restLms.ConductSurvey.projection;

public interface ConductSurveySubject {
    String getSubjectId();

    String getSubjectName();
    
}
