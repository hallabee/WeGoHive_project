package com.dev.restLms.ConductSurvey.projection;

public interface ConductSurveyCourse {
    String getCourseId();

    String getSessionId();
    String getCourseTitle();
    String getCourseEndDate();
    String getCourseStartDate();

}
