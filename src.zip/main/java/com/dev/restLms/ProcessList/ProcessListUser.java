package com.dev.restLms.ProcessList;

public interface ProcessListUser {
     String getSessionId();

     String getUserName();

    
}
