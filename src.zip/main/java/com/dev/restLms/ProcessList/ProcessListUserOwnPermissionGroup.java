package com.dev.restLms.ProcessList;

public interface ProcessListUserOwnPermissionGroup {

     String getPermissionGroupUuid2();

     String getSessionId();
    
}
