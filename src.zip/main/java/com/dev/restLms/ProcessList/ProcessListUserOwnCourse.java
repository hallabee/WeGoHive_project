package com.dev.restLms.ProcessList;

public interface ProcessListUserOwnCourse {

     String getIncreaseId();
    
     String getSessionId();

     String getCourseId();

     String getOfficerSessionId();

     String getCourseApproval();
}
