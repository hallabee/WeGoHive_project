package com.dev.restLms.ProcessList;

public interface ProcessListAssignment {
    String getAssignmentId();
    String getTeacherSessionId();
}
