package com.dev.restLms.ProcessList;

public interface ProcessListCourse {
	 String getCourseId(); 
	
	 String getSessionId();

	 String getCourseTitle();
	
	 String getCourseCapacity();

	 String getEnrollStartDate();

	 String getEnrollEndDate();

	 String getCourseImg();
	
}
