package com.dev.restLms.QuestionBoardPost;

public interface QuestionBoardPostBoard {
    String getBoardId();
    
    String getTeacherSessionId();
    String getOfferedSubjectsId();
}
