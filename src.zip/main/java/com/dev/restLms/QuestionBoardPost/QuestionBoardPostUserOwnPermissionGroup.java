package com.dev.restLms.QuestionBoardPost;

public interface QuestionBoardPostUserOwnPermissionGroup {

     String getPermissionGroupUuid2();

     String getSessionId();
    
}
