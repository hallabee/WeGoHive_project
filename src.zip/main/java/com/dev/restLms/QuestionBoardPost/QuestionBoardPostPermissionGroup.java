package com.dev.restLms.QuestionBoardPost;

public interface QuestionBoardPostPermissionGroup {
     String getPermissionGroupUuid();

     String getPermissionName();
    
}
