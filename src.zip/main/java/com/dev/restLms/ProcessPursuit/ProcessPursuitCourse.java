package com.dev.restLms.ProcessPursuit;

public interface ProcessPursuitCourse {
	 String getCourseId(); 
	
	 String getSessionId();
	 String getCourseTitle();
	 String getCourseCapacity();
	 String getEnrollStartDate();
	 String getEnrollEndDate();
	
}
