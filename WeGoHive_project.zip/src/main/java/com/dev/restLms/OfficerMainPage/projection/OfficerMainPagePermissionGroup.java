package com.dev.restLms.OfficerMainPage.projection;

public interface OfficerMainPagePermissionGroup {
    String getPermissionGroupUuid();

    String getPermissionName();
}
