package com.dev.restLms.SurveyStatistics.projection;

public interface SurveyStatisticsSurveyQuestion {
    String getSurveyQuestionId();

    String getQuestionData();
    String getAnswerCategory();
    String getSurveyCategory();
}
