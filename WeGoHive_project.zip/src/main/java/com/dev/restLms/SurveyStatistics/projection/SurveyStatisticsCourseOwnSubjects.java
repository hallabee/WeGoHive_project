package com.dev.restLms.SurveyStatistics.projection;

public interface SurveyStatisticsCourseOwnSubjects {
    String getCourseId();
    String getSubjectId();
}
