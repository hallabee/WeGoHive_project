package com.dev.restLms.SurveyStatistics.projection;

public interface SurveyStatisticsCourse {
    String getCourseId();

    String getSessionId();
    String getCourseTitle();
    String getCourseEndDate();
}
