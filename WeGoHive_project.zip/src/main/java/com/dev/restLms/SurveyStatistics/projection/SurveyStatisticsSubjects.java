package com.dev.restLms.SurveyStatistics.projection;

public interface SurveyStatisticsSubjects {
    String getSubjectId();

    String getSubjectName();
}
