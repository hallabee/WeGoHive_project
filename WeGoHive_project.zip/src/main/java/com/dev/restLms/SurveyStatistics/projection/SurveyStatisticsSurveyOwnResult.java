package com.dev.restLms.SurveyStatistics.projection;

public interface SurveyStatisticsSurveyOwnResult {

    String getIncreaseId();

    String getSurveyExecutionId();
    String getSessionId();
    String getSurveyQuestionId();
    String getSurveyAnswerId();
    
}
