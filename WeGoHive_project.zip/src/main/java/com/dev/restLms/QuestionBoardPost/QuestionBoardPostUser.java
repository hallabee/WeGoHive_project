package com.dev.restLms.QuestionBoardPost;

public interface QuestionBoardPostUser {
    String getSessionId();

    String getNickname();
}
