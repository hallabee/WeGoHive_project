package com.dev.restLms.QuestionBoardPost;

public interface QuestionBoardPostUserOwnAssignment {
    String getUserSessionId();
    String getOfferedSubjectsId();
}
