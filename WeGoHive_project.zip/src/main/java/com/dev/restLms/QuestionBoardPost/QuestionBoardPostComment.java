package com.dev.restLms.QuestionBoardPost;

public interface QuestionBoardPostComment {

     String getCommentId();

     String getAuthorNickname();

     String getCreatedDate();

     String getContent();

     String getPostId();

     String getSessionId();
    
}
