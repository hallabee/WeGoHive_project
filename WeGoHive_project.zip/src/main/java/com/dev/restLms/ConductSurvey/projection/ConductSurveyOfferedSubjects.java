package com.dev.restLms.ConductSurvey.projection;

public interface ConductSurveyOfferedSubjects {
    String getOfferedSubjectsId();

    String getCourseId();
    String getSubjectId();
    String getOfficerSessionId();
    String getTeacherSessionId();
}
