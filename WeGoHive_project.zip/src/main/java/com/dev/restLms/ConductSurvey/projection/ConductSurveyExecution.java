package com.dev.restLms.ConductSurvey.projection;

public interface ConductSurveyExecution {
    String getSurveyExecutionId();

    String getOfferedSubjectsId();
    String getCourseId();
    String getSessionId();
}
