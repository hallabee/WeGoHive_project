package com.dev.restLms.userSubjects;

public interface userSubjectsCourseOwnSubject {
    String getIncreaseId();
    String getSubjectId();
}
