package com.dev.restLms.userSubjects;

public interface userSubjectsSubjectOwnVideo {
    String getEpisodeId();
    String getSovOfferedSubjectsId();
}
