package com.dev.restLms.announcementPost;

public interface announcementPostBoardPost {

    String getPostId();

    String getAuthorNickname();
    String getCreatedDate();
    String getTitle();
    String getContent();
    String getSessionId();
    String getIsNotice();
    String getFileNo();
    
}
