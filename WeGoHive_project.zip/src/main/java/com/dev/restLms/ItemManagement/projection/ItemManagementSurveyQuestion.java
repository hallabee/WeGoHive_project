package com.dev.restLms.ItemManagement.projection;

public interface ItemManagementSurveyQuestion {
    String getSurveyQuestionId();
    String getQuestionData();
    String getAnswerCategory();
}
