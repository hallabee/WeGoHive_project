package com.dev.restLms.ItemManagement.projection;

public interface ItemManagementSurveyOwnResult {
    String getSurveyQuestionId();
}
