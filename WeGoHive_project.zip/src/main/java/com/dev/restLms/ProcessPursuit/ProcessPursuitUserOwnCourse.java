package com.dev.restLms.ProcessPursuit;

public interface ProcessPursuitUserOwnCourse {

     String getSessionId();

     String getCourseId();
}
