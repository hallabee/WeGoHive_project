package com.dev.restLms.ProcessPursuit;

public interface ProcessPursuitUser {

     String getSessionId();

     String getUserName();
    
}
