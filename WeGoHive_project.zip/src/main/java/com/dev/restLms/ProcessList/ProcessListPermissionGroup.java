package com.dev.restLms.ProcessList;

public interface ProcessListPermissionGroup {

     String getPermissionGroupUuid();

     String getPermissionName();
    
}
