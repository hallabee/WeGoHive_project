package com.dev.restLms.ProcessList;

public interface ProcessListUserOwnAssignment {

     String getIncreaseId();
    
     String getUserSessionId();

     String getOfferedSubjectsId();

     String getSubjectAcceptCategory();
    
}
