package com.dev.restLms.ProcessList;

public interface ProcessListSubjectOwnVideo {
	 String getEpisodeId();

	 String getSovOfferedSubjectsId();

}
