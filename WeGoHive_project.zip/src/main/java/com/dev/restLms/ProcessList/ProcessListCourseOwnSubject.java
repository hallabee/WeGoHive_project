package com.dev.restLms.ProcessList;

public interface ProcessListCourseOwnSubject {

     String getIncreaseId();
    
     String getCourseId();
    
	 String getOfficerSessionId();
	
	 String getSubjectId();

      String getSubjectApproval();
    
}
