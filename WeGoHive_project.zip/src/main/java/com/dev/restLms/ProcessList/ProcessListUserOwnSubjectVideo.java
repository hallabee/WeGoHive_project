package com.dev.restLms.ProcessList;

public interface ProcessListUserOwnSubjectVideo {
     String getIncreaseId();

     String getUosvSessionId();

     String getUosvEpisodeId();

     String getUosvOfferedSubjectsId();

     String getProgress();
}
