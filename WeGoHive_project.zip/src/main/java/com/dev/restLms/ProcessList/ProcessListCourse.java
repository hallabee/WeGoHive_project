package com.dev.restLms.ProcessList;

public interface ProcessListCourse {
	 String getCourseId(); 
	
	 String sessionId();

	 String getCourseTitle();
	
	 String getCourseCapacity();

	 String getEnrollStartDate();

	 String getEnrollEndDate();

	 String getCourseImg();
	
}
