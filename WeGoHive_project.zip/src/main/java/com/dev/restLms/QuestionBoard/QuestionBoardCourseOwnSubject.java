package com.dev.restLms.QuestionBoard;

public interface QuestionBoardCourseOwnSubject {

     String getIncreaseId();
    
     String getSubjectId();
    
}
