package com.dev.restLms.QuestionBoard;

public interface QuestionBoard {
     String getBoardId();

     String getBoardCategory();

     String getTeacherSessionId();

     String getOfferedSubjectsId();
}
