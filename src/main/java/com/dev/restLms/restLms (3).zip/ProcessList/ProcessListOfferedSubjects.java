package com.dev.restLms.ProcessList;

public interface ProcessListOfferedSubjects {
	 String getOfferedSubjectsId();

	 String getCourseId(); 
	
	 String getOfficerSessionId();
	
	 String getSubjectId();
}
