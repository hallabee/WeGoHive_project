package com.dev.restLms.FreeBulletinBoardPost;

public interface FreeBulletinBoardPostUser {
    String getSessionId();

    String getNickname();
}
