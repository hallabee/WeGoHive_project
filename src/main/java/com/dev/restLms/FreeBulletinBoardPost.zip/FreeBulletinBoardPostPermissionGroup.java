package com.dev.restLms.FreeBulletinBoardPost;

public interface FreeBulletinBoardPostPermissionGroup {

    String getPermissionGroupUuid();

    String getPermissionName();
    
}
