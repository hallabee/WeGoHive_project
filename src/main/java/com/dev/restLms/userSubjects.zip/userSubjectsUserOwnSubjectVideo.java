package com.dev.restLms.userSubjects;

public interface userSubjectsUserOwnSubjectVideo {
    String getIncreaseId();
    String getUosvSessionId();
    String getUosvEpisodeId();
    String getUosvOfferedSubjectsId();
    String getProgress();
}
