package com.dev.restLms.announcementPost;

public interface announcementPostPermissionGroup {

    String getPermissionGroupUuid();

    String getPermissionName();
    
}
