package com.dev.restLms.announcementPost;

public interface announcementPostUser {

    String getSessionId();

    String getNickname();
    
}
