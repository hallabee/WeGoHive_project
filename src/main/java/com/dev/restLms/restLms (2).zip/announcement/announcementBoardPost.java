package com.dev.restLms.announcement;

public interface announcementBoardPost {
    
    String getPostId();

    String getAuthorNickname();

    String getCreatedDate();

    String getTitle();

    String getContent();

    String getBoardId();

    String getSessionId();

    String getIsNotice();

    String getFileNo();

}
