package com.dev.restLms.announcement;

public interface announcementBoard {

    String getBoardId();

    String getBoardCategory();
    
}
