package com.dev.restLms.FreeBulletinBoard;

public interface FreeBulletinBoard {

    String getBoardId();

    String getBoardCategory();
    
}
