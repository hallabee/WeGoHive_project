package com.dev.restLms.FreeBulletinBoardPost;

public interface FreeBulletinBoardPosts {

    String getPostId();

    String getAuthorNickname();
    String getCreatedDate();
    String getTitle();
    String getContent();
    String getSessionId();
    String getFileNo();
    
}
